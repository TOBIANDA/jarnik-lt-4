#!/bin/sh
# Bangun WifiScanMac.app (pembantu scan Wi-Fi macOS). Perlu Xcode Command Line Tools:
#   xcode-select --install
# Jalankan dari folder kelompok:  sh mac_helper/build_mac_helper.sh
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
APP="$DIR/../WifiScanMac.app"
rm -rf "$APP"
mkdir -p "$APP/Contents/MacOS"
cat > "$APP/Contents/Info.plist" <<'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>CFBundleIdentifier</key><string>id.ac.ub.filkom.wifiscanmac</string>
  <key>CFBundleName</key><string>WifiScanMac</string>
  <key>CFBundleExecutable</key><string>WifiScanMac</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>CFBundleVersion</key><string>1.0</string>
  <key>CFBundleShortVersionString</key><string>1.0</string>
  <key>LSMinimumSystemVersion</key><string>13.0</string>
  <key>LSUIElement</key><true/>
  <key>NSLocationUsageDescription</key><string>macOS mewajibkan izin lokasi untuk membaca SSID/BSSID Wi-Fi (praktikum survei Wi-Fi).</string>
  <key>NSLocationWhenInUseUsageDescription</key><string>macOS mewajibkan izin lokasi untuk membaca SSID/BSSID Wi-Fi (praktikum survei Wi-Fi).</string>
</dict></plist>
PLIST
swiftc -O "$DIR/main.swift" -o "$APP/Contents/MacOS/WifiScanMac" \
  -framework CoreWLAN -framework CoreLocation -framework AppKit
codesign --force --sign - "$APP"
echo "Selesai: $APP"
